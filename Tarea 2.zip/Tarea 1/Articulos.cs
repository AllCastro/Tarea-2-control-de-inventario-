﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Control_De_Inventario
{
    internal class Articulos
    {
        public static int[] id = new int[3];             // Código del artículo
        public static string[] nombre = new string[3];   // Nombre del artículo
        public static decimal[] precio = new decimal[3]; // Precio del artículo
        public static int[] cantidad = new int[3];       // Cantidad en bodega
        public static string[] bodega = new string[3];   // Bodega donde se almacena

        // Método para inicializar arreglos 
        public static void inicializarArreglos()
        {
            for (int i = 0; i < id.Length; i++)
            {
                id[i] = 0;
                nombre[i] = "";
                precio[i] = 0;
                cantidad[i] = 0;
                bodega[i] = "";
            }

            Console.WriteLine("Los arreglos han sido inicializados");
            Console.Clear();
        }

        // Método para ingresar productos 
        public static void ingresarProductos()
        {
            Console.Clear();
            int indice = 0;
            while (indice < id.Length)
            {
                Console.Write("Digite un código: ");
                id[indice] = int.Parse(Console.ReadLine());

                Console.Write("Digite el nombre del artículo: ");
                nombre[indice] = Console.ReadLine();

                Console.Write("Digite el precio del artículo: ");
                precio[indice] = decimal.Parse(Console.ReadLine());

                Console.Write("Digite la cantidad en bodega: ");
                cantidad[indice] = int.Parse(Console.ReadLine());

                Console.Write("Digite la bodega donde se almacena el artículo: ");
                bodega[indice] = Console.ReadLine();

                indice++;
                Console.Clear();
            }

            Console.WriteLine("Los artículos han sido ingresados");
        }

        // Método para modificar productos 
        public static void modificarProductos()
        {
            Console.Clear();
            Console.WriteLine("Digite el código del artículo que desea modificar:");
            int codigoModificar = int.Parse(Console.ReadLine());

            for (int i = 0; i < id.Length; i++)
            {
                if (codigoModificar == id[i])
                {
                    Console.WriteLine($"Código: {id[i]} Nombre: {nombre[i]}");
                    Console.Write("Digite un nuevo nombre: ");
                    nombre[i] = Console.ReadLine();
                    break;
                }
            }
        }

        // Método para consultar productos 
        public static void consultarProductos()
        {
            Console.Clear();
            Console.WriteLine(" *** REPORTE DE ARTÍCULOS ***");
            for (int i = 0; i < id.Length; i++)
            {
                Console.WriteLine($"Código: {id[i]} Nombre: {nombre[i]} Precio: {precio[i]} Cantidad: {cantidad[i]} Bodega: {bodega[i]}");
            }
            Console.WriteLine("*** FIN DEL REPORTE ***");
        }

        // Método para eliminar productos 
        public static void excluirProductos()
        {
            Console.Clear();
            Console.WriteLine("Digite el código del artículo que desea eliminar:");
            int codigoExcluir = int.Parse(Console.ReadLine());

            for (int i = 0; i < id.Length; i++)
            {
                if (codigoExcluir == id[i])
                {
                    id[i] = 0;
                    nombre[i] = "";
                    precio[i] = 0;
                    cantidad[i] = 0;
                    bodega[i] = "";

                    Console.WriteLine("El artículo ha sido eliminado.");
                    break;
                }
            }
        }

        // Método para buscar productos por código o nombre
        public static void buscarProducto()
        {
            Console.Clear();
            Console.WriteLine("Digite el código o nombre del artículo que desea buscar:");
            string entrada = Console.ReadLine();

            bool encontrado = false;
            for (int i = 0; i < id.Length; i++)
            {
                if (entrada == id[i].ToString() || entrada.Equals(nombre[i], StringComparison.OrdinalIgnoreCase))
                {
                    Console.WriteLine($"Código: {id[i]} Nombre: {nombre[i]} Precio: {precio[i]} Cantidad: {cantidad[i]} Bodega: {bodega[i]}");
                    encontrado = true;
                }
            }

            if (!encontrado)
            {
                Console.WriteLine("Artículo no encontrado.");
            }
        }
    }
}